Leak Scanner - by kader11000

How to run:
-----------

1. Make sure you have Python 3 and Flask installed.
2. Place your RapidAPI key inside main.py at line 11 (replace 'your_api_key_here').
3. Open a terminal and navigate to the project directory, then run:

   python main.py

4. In your browser, go to: http://127.0.0.1:5000
5. Enter the password: kader11000
6. Then input keywords/domains separated by commas.
7. Press Start Search to begin scanning leaks.

Features:
---------
- Password-protected interface
- Multi-keyword search
- Online lookup via RapidAPI
- Hacker-style dark UI
- Terminal simulation display
- Filter, view, and export results
