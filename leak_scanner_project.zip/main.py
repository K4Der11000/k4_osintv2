from flask import Flask, render_template, request, redirect, url_for, session
import requests

app = Flask(__name__)
app.secret_key = "your_secret_key_here"  # Replace with a secure random key
PASSWORD = "kader11000"

def search_leaks(keywords):
    results = []
    for word in keywords:
        url = f"https://leak-lookup-api-demo.p.rapidapi.com/api/username/{word}"
        headers = {
            "X-RapidAPI-Key": "your_api_key_here",
            "X-RapidAPI-Host": "leak-lookup-api-demo.p.rapidapi.com"
        }
        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                data = response.json()
                for leak in data.get("leaks", []):
                    results.append(leak)
            else:
                results.append(f"Error fetching data for: {word}")
        except Exception as e:
            results.append(f"Exception: {e}")
    return results

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        password = request.form.get("password")
        if password == PASSWORD:
            session['authenticated'] = True
            return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/scanner", methods=["GET", "POST"])
def index():
    if not session.get("authenticated"):
        return redirect(url_for("login"))

    results = []
    if request.method == "POST":
        raw_input = request.form.get("keyword")
        if raw_input:
            keywords = [k.strip() for k in raw_input.split(",") if k.strip()]
            results = search_leaks(keywords)
    return render_template("index.html", results=results)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
